# Cloudflare Pages review and launch

## Approval boundary

The supplied brief requires approval before deployment or external account modifications. The code is prepared locally. Obtain approval for creating a dedicated GitHub repository and a new Cloudflare Pages project. Do not replace a dashboard project. Obtain separate explicit approval before connecting `authorcrest.world` or `www.authorcrest.world`.

Never alter MX, SPF, DKIM, DMARC, or `app.authorcrest.world`. Do not delete existing projects, Workers, repositories, or DNS records.

## Build settings

1. Create a separate repository named `authorcrest-website` after checking whether it already exists. Push this project only.
2. Connect it to a new Cloudflare Pages project, with the reviewed branch selected.
3. Set Node version to 24. Use the included pnpm lockfile for installation, `npm run build` as the build command, and `dist` as output. The root `functions/` directory must be deployed alongside the built assets.
4. Leave `PUBLIC_SITE=false` for review. The build adds noindex and disallow-all robots directives. Middleware also applies noindex on any hostname other than `authorcrest.world`, protecting preview deployments even when production is later indexable.
5. Open the generated Pages URL and repeat route, mobile, keyboard, form, header, and 404 checks. Pre-rendered directories serve deep links; no catch-all rewrite hides the actual route metadata.

## Submission infrastructure

Create a dedicated D1 database, apply `migrations/0001_forms.sql`, and bind it as `INQUIRY_DB` in the Pages environment. It stores hashed rate-limit keys and submission fingerprints/status, not raw inquiry content. Expired rows are purged on successful delivery; arrange periodic expiry cleanup if required by the final retention policy.

Set encrypted runtime secrets from `.env.example`:

| Setting | Purpose |
| --- | --- |
| `DELIVERY_URL` | Approved HTTPS endpoint that actually stores or forwards the inquiry |
| `DELIVERY_TOKEN` | Bearer credential for that service |
| `RATE_SALT` | Long randomly generated secret for hashing network identifiers |
| `NEWSLETTER_ENABLED` | `false` until subscription handling is operational |

Never prefix secrets with `VITE_`, put them in source control, or expose them in browser code. Local runtime secrets belong in ignored `.dev.vars`.

### Delivery endpoint contract

The function sends JSON with validated submitted fields, `kind` (`contact`, `assessment`, or `newsletter`), `recipient` fixed to `info@authorcrest.world`, and `receivedAt`. Headers include `Authorization: Bearer …` and `Idempotency-Key` (a stable submission fingerprint). The endpoint must honor the idempotency key, securely handle the data, and return a 2xx response only after accepting it durably or confirming successful forwarding. It must treat all field text as untrusted and escape it if placing it into HTML email. Redirects are refused. The request times out after 12 seconds; the provider must deduplicate retries after an ambiguous timeout.

For newsletter requests, the endpoint must manage double opt-in confirmation, subscription state, and unsubscribe handling. Do not set `NEWSLETTER_ENABLED=true` merely to make the form appear operational. The UI currently requests affirmative consent and reports only that a subscription request was received.

Missing secrets/bindings return 503; delivery failure returns 502; duplicates in progress return 409; more than five attempts per network identifier per ten-minute window return 429. Honeypot and timing checks supplement rate limiting. Add a challenge service if real abuse requires it, with server verification and privacy notice updates.

### Local backend testing

Use Cloudflare Wrangler Pages with `dist`, a local D1 binding, the applied migration, and `.dev.vars`. Automated tests use an in-memory SQLite adapter plus a simulated delivery endpoint; they do not prove delivery through a real provider. Do not send test inquiries to the business without permission.

## Before public launch

Complete the policy review fields, configure and verify real delivery, test double opt-in/unsubscribe if newsletter is enabled, review fonts and privacy details, and obtain launch approval. Only the approved production build should set `PUBLIC_SITE=true`. Verify the custom domain and canonical redirect behavior without modifying email records.

Cloudflare reference documentation consulted: [Pages bindings](https://developers.cloudflare.com/pages/functions/bindings/), [redirect behavior](https://developers.cloudflare.com/pages/configuration/redirects/).
