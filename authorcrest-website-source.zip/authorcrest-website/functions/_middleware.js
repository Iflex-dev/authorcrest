export async function onRequest({request,next}){
 const response=await next();
 const result=new Response(response.body,response);
 if(new URL(request.url).hostname!=='authorcrest.world')result.headers.set('X-Robots-Tag','noindex, nofollow');
 return result;
}
