import {validateSubmission} from '../../server/validation.mjs';
const reply=(status,data)=>Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
export async function onRequestPost({request,env}){
 const origin=new URL(request.url).origin;
 if(request.headers.get('Origin')!==origin)return reply(403,{error:'This request must come from the website.'});
 if(!request.headers.get('Content-Type')?.includes('application/json'))return reply(415,{error:'Use JSON.'});
 if(Number(request.headers.get('Content-Length'))>24000)return reply(413,{error:'Please shorten your message.'});
 let data;try{const raw=await request.text();if(raw.length>24000)return reply(413,{error:'Please shorten your message.'});data=JSON.parse(raw);}catch{return reply(400,{error:'Invalid request.'});}
 const validation=validateSubmission(data);if(validation)return reply(400,{error:validation});
 if(!env.INQUIRY_DB||!env.DELIVERY_URL||!env.DELIVERY_TOKEN||!env.RATE_SALT)return reply(503,{error:'Online delivery is not enabled yet. Please email info@authorcrest.world.'});
 if(data.kind==='newsletter'&&env.NEWSLETTER_ENABLED!=='true')return reply(503,{error:'Newsletter enrollment is not open yet. Please check back later.'});
 let destination;try{destination=new URL(env.DELIVERY_URL);if(destination.protocol!=='https:')throw new Error();}catch{return reply(503,{error:'Online delivery is temporarily unavailable. Please email info@authorcrest.world.'});}
 const hash=async value=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)))).map(b=>b.toString(16).padStart(2,'0')).join('');
 const now=Math.floor(Date.now()/1000),window=Math.floor(now/600);const ip=request.headers.get('CF-Connecting-IP')||'unknown';const key=await hash(env.RATE_SALT+ip+window);
 try{
 const rate=await env.INQUIRY_DB.prepare('INSERT INTO rate_limits (key, count, expires) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1 RETURNING count').bind(key,now+1200).first();
 if(rate.count>5)return reply(429,{error:'Too many requests. Please try again in ten minutes.'});
 const clean=Object.fromEntries(Object.entries(data).filter(([k])=>!['started','company_url'].includes(k)));const id=await hash(JSON.stringify(clean));
 const claim=await env.INQUIRY_DB.prepare('INSERT OR IGNORE INTO submissions (key, status, expires) VALUES (?, ?, ?)').bind(id,'pending',now+86400).run();
 if(!claim.meta.changes){const old=await env.INQUIRY_DB.prepare('SELECT status FROM submissions WHERE key=?').bind(id).first();if(old?.status==='sent')return reply(200,{ok:true});return reply(409,{error:'This inquiry is already being processed. Please wait before retrying.'});}
 let delivered=false;try{const response=await fetch(destination.href,{method:'POST',redirect:'error',headers:{'Authorization':`Bearer ${env.DELIVERY_TOKEN}`,'Content-Type':'application/json','Idempotency-Key':id},body:JSON.stringify({...clean,recipient:'info@authorcrest.world',receivedAt:new Date().toISOString()}),signal:AbortSignal.timeout(12000)});delivered=response.ok;}catch{}
 if(!delivered){await env.INQUIRY_DB.prepare('DELETE FROM submissions WHERE key=?').bind(id).run();return reply(502,{error:'Delivery could not be confirmed. Please retry or email info@authorcrest.world.'});}
 await env.INQUIRY_DB.prepare('UPDATE submissions SET status=? WHERE key=?').bind('sent',id).run();
 await env.INQUIRY_DB.batch([env.INQUIRY_DB.prepare('DELETE FROM rate_limits WHERE expires<?').bind(now),env.INQUIRY_DB.prepare('DELETE FROM submissions WHERE expires<?').bind(now)]);
 return reply(200,{ok:true});
 }catch{return reply(503,{error:'Online delivery is temporarily unavailable. Please email info@authorcrest.world.'});}
}
export const onRequestGet=()=>reply(405,{error:'Use POST.'});
