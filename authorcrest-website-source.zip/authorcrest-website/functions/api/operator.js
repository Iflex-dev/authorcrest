import {json,body,now,hash,limited,snapshot,cleanup} from '../../server/chat.mjs';
export async function onRequest({request,env}){
 try{
 if(!env.OPERATOR_TOKEN||env.OPERATOR_TOKEN.length<32||!env.INQUIRY_DB||!env.RATE_SALT)return json(503,{error:'The operator inbox is not configured.'});
 if(await limited(env,'operator:'+ (request.headers.get('CF-Connecting-IP')||'unknown'),120,60))return json(429,{error:'Too many requests.'});
 const supplied=request.headers.get('Authorization')||'';
 if(await hash(supplied)!==await hash('Bearer '+env.OPERATOR_TOKEN))return json(401,{error:'Invalid operator access key.'});
 if(request.method==='GET'){
 await cleanup(env);const id=new URL(request.url).searchParams.get('id');
 if(id){const s=await env.INQUIRY_DB.prepare('SELECT * FROM chat_sessions WHERE id=? AND expires>?').bind(id,now()).first();return s?json(200,{...await snapshot(env,s),id:s.id,email:s.email}):json(404,{error:'Conversation not found.'});}
 const list=await env.INQUIRY_DB.prepare("SELECT id,mode,name,email,updated,notified FROM chat_sessions WHERE mode IN ('waiting','human') AND expires>? ORDER BY updated DESC LIMIT 100").bind(now()).all();return json(200,{sessions:list.results});
 }
 if(request.method!=='POST')return json(405,{error:'Use GET or POST.'});
 if(request.headers.get('Origin')!==new URL(request.url).origin)return json(403,{error:'Use the operator inbox on this website.'});
 const data=await body(request);if(typeof data.id!=='string')return json(400,{error:'Select a conversation.'});
 const s=await env.INQUIRY_DB.prepare('SELECT * FROM chat_sessions WHERE id=? AND expires>?').bind(data.id,now()).first();if(!s)return json(404,{error:'Conversation not found.'});
 if(data.action==='takeover'){
 if(s.mode==='closed')return json(409,{error:'This conversation is closed.'});
 await env.INQUIRY_DB.prepare("UPDATE chat_sessions SET mode='human',busy='',busy_until=0,updated=? WHERE id=?").bind(now(),s.id).run();
 await env.INQUIRY_DB.prepare("INSERT OR IGNORE INTO chat_messages(session_id,role,content,created,request_id) VALUES (?,'system',?,?,?)").bind(s.id,'An AuthorCrest team member has joined. AI replies are paused.',now(),'human-joined').run();
 }else if(data.action==='close'){
 await env.INQUIRY_DB.prepare("UPDATE chat_sessions SET mode='closed',busy='',busy_until=0,updated=? WHERE id=?").bind(now(),s.id).run();
 }else if(data.action==='reply'){
 if(s.mode!=='human')return json(409,{error:'Take over this conversation before replying.'});
 if(typeof data.message!=='string'||!data.message.trim()||data.message.length>4000||typeof data.requestId!=='string'||!/^[a-zA-Z0-9-]{8,80}$/.test(data.requestId))return json(400,{error:'Enter a reply up to 4,000 characters.'});
 await env.INQUIRY_DB.prepare("INSERT OR IGNORE INTO chat_messages(session_id,role,content,created,request_id) SELECT id,'human',?,?,? FROM chat_sessions WHERE id=? AND mode='human'").bind(data.message.trim(),now(),data.requestId,s.id).run();
 await env.INQUIRY_DB.prepare('UPDATE chat_sessions SET updated=? WHERE id=?').bind(now(),s.id).run();
 }else return json(400,{error:'Unknown action.'});
 return json(200,{...await snapshot(env,s),id:s.id,email:s.email});
 }catch{return json(503,{error:'The inbox is temporarily unavailable.'});}
}
