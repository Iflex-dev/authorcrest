import {json,body,hash,now,limited,session,snapshot,aiReady,cleanup,generate,notifyHandoff,CHAT_NOTICE} from '../../server/chat.mjs';
export async function onRequest({request,env}){
 try{
 if(request.method==='GET'&&new URL(request.url).searchParams.get('config')==='1')return json(200,{enabled:Boolean(env.INQUIRY_DB&&env.RATE_SALT),ai:aiReady(env),notice:CHAT_NOTICE});
 if(!env.INQUIRY_DB||!env.RATE_SALT)return json(503,{error:'Chat is not connected yet. Please email info@authorcrest.world.'});
 if(request.method==='GET'){if(await limited(env,'chat-poll:'+(request.headers.get('CF-Connecting-IP')||'unknown'),120,60))return json(429,{error:'Too many updates. Please wait a minute.'});const s=await session(request,env);return s?json(200,await snapshot(env,s)):json(401,{error:'Start a new conversation.'});}
 if(request.method!=='POST')return json(405,{error:'Use POST or GET.'});
 if(request.headers.get('Origin')!==new URL(request.url).origin)return json(403,{error:'This request must come from the website.'});
 const data=await body(request);const ip=request.headers.get('CF-Connecting-IP')||'unknown';
 if(await limited(env,'chat:'+ip,40,600))return json(429,{error:'Too many requests. Please try again in ten minutes.'});
 if(data.action==='start'){
 if(data.consent!==true)return json(400,{error:'Please agree to the chat privacy notice.'});
 const existing=await session(request,env);if(existing&&existing.mode!=='closed')return json(200,await snapshot(env,existing));
 if(await limited(env,'chat-start:'+ip,5,600))return json(429,{error:'Please wait before starting another conversation.'});
 await cleanup(env);const token=crypto.randomUUID().replaceAll('-','')+crypto.randomUUID().replaceAll('-','');const id=crypto.randomUUID();
 await env.INQUIRY_DB.prepare('INSERT INTO chat_sessions(id,token_hash,language,created,updated,expires) VALUES (?,?,?,?,?,?)').bind(id,await hash(token),['en','es','fr'].includes(data.language)?data.language:'en',now(),now(),now()+604800).run();
 return json(200,{mode:'ai',messages:[]},{'Set-Cookie':`ac_chat=${token}; Path=/api/chat; HttpOnly; Secure; SameSite=Strict; Max-Age=604800`});
 }
 const s=await session(request,env);if(!s)return json(401,{error:'Your conversation expired. Please start again.'});
 if(data.action==='end'){await env.INQUIRY_DB.prepare("UPDATE chat_sessions SET mode='closed',busy='',busy_until=0 WHERE id=?").bind(s.id).run();return json(200,{ended:true},{'Set-Cookie':'ac_chat=; Path=/api/chat; HttpOnly; Secure; SameSite=Strict; Max-Age=0'});}
 if(s.mode==='closed')return json(409,{error:'This conversation is closed. Please start again.'});
 if(data.action==='handoff'){
 if(!env.OPERATOR_TOKEN||env.OPERATOR_TOKEN.length<32)return json(503,{error:'Human chat is not connected yet. Please email info@authorcrest.world.'});
 if(data.consent!==true||typeof data.name!=='string'||!data.name.trim()||data.name.length>120||typeof data.email!=='string'||data.email.length>254||!/^\S+@\S+\.\S+$/.test(data.email))return json(400,{error:'Enter your name, a valid email, and consent to contact.'});
 await env.INQUIRY_DB.prepare("UPDATE chat_sessions SET mode=CASE WHEN mode='human' THEN 'human' ELSE 'waiting' END,name=?,email=?,busy='',busy_until=0,updated=? WHERE id=?").bind(data.name.trim(),data.email.trim(),now(),s.id).run();
 const fresh=await env.INQUIRY_DB.prepare('SELECT * FROM chat_sessions WHERE id=?').bind(s.id).first();const notified=await notifyHandoff(env,fresh);
 return json(200,{...await snapshot(env,s),notified: notified?1:0,notice:notified?'Your request is saved and a notification was sent. A person has not joined yet.':'Your request is saved in the support inbox, but email notification could not be confirmed. You may also email info@authorcrest.world.'});
 }
 if(data.action!=='message'||typeof data.message!=='string'||!data.message.trim()||data.message.length>2000||typeof data.requestId!=='string'||!/^[a-zA-Z0-9-]{8,80}$/.test(data.requestId))return json(400,{error:'Enter a message up to 2,000 characters.'});
 if(s.mode==='ai'){if(!aiReady(env))return json(503,{error:'The AI assistant is not connected yet. You can request a person instead.'});return await generate(env,s,data.message.trim(),data.requestId);}
 const count=await env.INQUIRY_DB.prepare('SELECT count(*) AS n FROM chat_messages WHERE session_id=?').bind(s.id).first();if(count.n>=180)return json(429,{error:'This conversation is full. Please email us to continue.'});
 await env.INQUIRY_DB.prepare("INSERT OR IGNORE INTO chat_messages(session_id,role,content,created,request_id) SELECT id,'user',?,?,? FROM chat_sessions WHERE id=? AND mode IN ('waiting','human')").bind(data.message.trim(),now(),data.requestId,s.id).run();
 await env.INQUIRY_DB.prepare('UPDATE chat_sessions SET updated=? WHERE id=?').bind(now(),s.id).run();return json(200,await snapshot(env,s));
 }catch{return json(503,{error:'Chat is temporarily unavailable. Please email info@authorcrest.world.'});}
}
