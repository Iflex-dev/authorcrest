CREATE TABLE IF NOT EXISTS chat_sessions (
 id TEXT PRIMARY KEY, token_hash TEXT NOT NULL UNIQUE,
 mode TEXT NOT NULL DEFAULT 'ai', name TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '',
 language TEXT NOT NULL DEFAULT 'en', created INTEGER NOT NULL, updated INTEGER NOT NULL,
 expires INTEGER NOT NULL, busy TEXT NOT NULL DEFAULT '', busy_until INTEGER NOT NULL DEFAULT 0,
 notified INTEGER NOT NULL DEFAULT 0, notify_attempt INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS chat_messages (
 id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT NOT NULL,
 role TEXT NOT NULL, content TEXT NOT NULL, created INTEGER NOT NULL,
 request_id TEXT NOT NULL, UNIQUE(session_id, request_id)
);
CREATE INDEX IF NOT EXISTS chat_message_session ON chat_messages(session_id, id);
CREATE INDEX IF NOT EXISTS chat_expiry ON chat_sessions(expires);
