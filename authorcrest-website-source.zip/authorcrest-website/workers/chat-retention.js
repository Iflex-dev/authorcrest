// Deploy separately as a scheduled Worker bound to the same INQUIRY_DB database.
// Schedule: 0 * * * * (hourly). Do not replace an existing Worker.
export default {
 async scheduled(_event,env,ctx){
  const time=Math.floor(Date.now()/1000);
  ctx.waitUntil(env.INQUIRY_DB.batch([
   env.INQUIRY_DB.prepare('DELETE FROM chat_messages WHERE session_id IN (SELECT id FROM chat_sessions WHERE expires<?)').bind(time),
   env.INQUIRY_DB.prepare('DELETE FROM chat_sessions WHERE expires<?').bind(time),
   env.INQUIRY_DB.prepare('DELETE FROM rate_limits WHERE expires<?').bind(time),
   env.INQUIRY_DB.prepare('DELETE FROM submissions WHERE expires<?').bind(time)
  ]));
 }
};
