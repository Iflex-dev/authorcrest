export function validateSubmission(data,now=Date.now()){
 if(!data||typeof data!=='object'||Array.isArray(data))return 'Invalid submission.';
 if(!['contact','assessment','newsletter'].includes(data.kind))return 'Choose a valid inquiry type.';
 if(data.company_url)return 'Unable to accept this submission.';
 if(typeof data.started!=='number'||now-data.started<2500||now-data.started>86400000)return 'Please refresh the form and take a moment before submitting.';
 if(data.consent!=='on')return 'Please confirm your consent.';
 const allowed=['kind','started','company_url','consent','name','email','bookTitle','genre','status','publicationDate','description','challenges','objectives','website','service','budget','message'];
 for(const [key,value]of Object.entries(data)){if(!allowed.includes(key))return 'Unknown form field.';if(key!=='started'&&(typeof value!=='string'||value.length>5000))return 'A field is too long or invalid.';}
 if(typeof data.email!=='string'||data.email.length>254||!/^\S+@\S+\.\S+$/.test(data.email)||/[\r\n]/.test(data.email))return 'Enter a valid email address.';
 if(data.kind!=='newsletter'&&(!data.name?.trim()||data.name.length>120))return 'Enter your name (up to 120 characters).';
 if(data.kind==='contact'&&!data.message?.trim())return 'Tell us how we can help.';
 if(data.kind==='assessment'){for(const field of ['bookTitle','genre','status','description','challenges','objectives'])if(!data[field]?.trim())return 'Complete all required book and marketing details.';if(data.website){try{if(!['https:','http:'].includes(new URL(data.website).protocol))return 'Enter a valid website link.';}catch{return 'Enter a valid website link.';}}}
 return null;
}
