// Only publish assets after the owner has approved their rights and copy.
export type ApprovedAsset={title:string;kind:'book'|'trailer'|'interview'|'guide'|'preview'|'retailer'|'media-kit'|'testimonial';approved:boolean;url:string;description:string};
export const assets:ApprovedAsset[]=[];
export const publishedAssets=assets.filter(asset=>asset.approved);
