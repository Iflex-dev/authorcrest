export const trustpilot={url:'https://www.trustpilot.com/review/authorcrest.world',score:'3.7',count:1,checked:'October 29, 2026'};
// Short public excerpt. This is not a verified-purchase claim or an agency result claim.
export const reviews=[{name:'Isabella Biscoe',quote:'Authorcrest provides exceptional service and top-notch marketing strategies.',date:'October 19, 2026',source:'Trustpilot',url:'https://www.trustpilot.com/reviews/6ad60b31a113a9704be2201c',approved:true}];
