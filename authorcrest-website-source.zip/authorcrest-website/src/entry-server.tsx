import {renderToString} from 'react-dom/server';
import {StaticRouter} from 'react-router-dom';
import {App} from './main';
export function render(url:string){return renderToString(<StaticRouter location={url}><App/></StaticRouter>);}
