# Verification and launch checklist

## Verified locally — October 29, 2026

- TypeScript check and production client/server-render builds pass.
- Static content and metadata generated for 16 routes. Search indexing disabled by default.
- 17 automated tests pass: input validation, consent, honeypot, timing, malformed email, incomplete assessment, oversize and unknown fields, newsletter consent, missing configuration, same-origin enforcement, delivery failure, duplicate suppression, and rate limiting. Delivery tests execute SQL against an in-memory SQLite database with a simulated upstream service.
- Headless Chrome: all primary routes, an article, and branded unknown-route view load with no page errors.
- Resource search filters articles; assessment advances to step three and preserves entered book details when moving back.
- 1440px desktop and 390px mobile homepage screenshots reviewed. No horizontal overflow on tested routes; mobile navigation reaches Contact.
- Reduced-motion emulation avoids a WebGL canvas and shows the static book.
- Production dependency audit reports no known vulnerabilities at check time.
- Original supplied logo preserved. Official email, Instagram, and Facebook links match the user’s supplied values.

Evidence: `qa/browser-results.json`, `qa/home-desktop.png`, `qa/home-mobile.png`. `scripts/browser-check.cjs` can rerun browser checks when Playwright and Chrome are available; set `PLAYWRIGHT_PACKAGE` to a package.json path whose dependencies include Playwright if it is not installed locally.

## Remaining verification

- Actual Cloudflare Pages deployment, D1 binding, runtime headers, production HTTP 404, and live end-to-end delivery have not been tested.
- Real provider credentials, approved destination, double opt-in, unsubscribe, retention, and deletion operations remain external setup.
- Safari, Firefox, physical mobile devices, screen-reader behavior, full keyboard audit, and measured Lighthouse/Core Web Vitals remain unverified.
- Social destinations were supplied by the user; ownership and current destination availability have not been independently verified.
- The 3D chunk is approximately 181 KB compressed and lazy-loaded. It is skipped for reduced-motion and data-saving preferences. Scores and field performance are not guaranteed.
- Google Fonts makes external font requests; complete the final hosting/privacy decision before launch.
- Policy templates contain explicit review fields. No fabricated results, reviews, or endorsements are published.

## Concierge and showcase update — October 29, 2026

- Added seven backend tests covering chat consent, session isolation, operator authentication, the Gmail notification destination, notification failure, duplicate replies, missing configuration, and takeover while an AI response is in progress.
- Added checks for Spanish/French document language and exclusion of the operator page from the sitemap.
- Trustpilot profile was read directly: one public review, 3.7/5 TrustScore, snapshot dated October 29, 2026. The site uses a short attributed excerpt rather than generated testimonials.
- Book covers and the interactive motion teaser are explicitly fictional concepts. No client assets, endorsements, or performance metrics were invented.
- Live OpenAI replies, real email notifications, Cloudflare D1 deployment, and scheduled retention cleanup remain untested without credentials and deployment.
- Final TypeScript, client build, pre-render build, and **25 automated tests pass**. Browser checks pass for motion playback/pause, language switching, consultation routes, disconnected chat, a simulated visitor-to-human handoff, operator login/takeover/reply, and global animation pause/resume. No page errors or horizontal overflow occurred at 1440px or 390px. Evidence: `qa/enhancements-results.json` and the new review, cover, and mobile chat screenshots.

## Updated launch checklist

- [ ] Approve the design and copy in local preview.
- [ ] Approve creation/use of the dedicated GitHub and Cloudflare projects.
- [ ] Configure D1 and approved delivery integration; verify failure, retry, duplicate, and success states on Pages.
- [ ] Enable newsletter only after confirmation and unsubscribe flows pass.
- [ ] Complete policy drafts with business identity and operational details.
- [ ] Test browser/device/accessibility coverage and measure performance.
- [ ] Verify external links and all Pages routes/assets.
- [ ] Approve public deployment and custom-domain connection.
- [ ] Verify email DNS and dashboard configuration remain unchanged.
- [ ] Enable production indexing only after final approval and confirm preview noindex.

