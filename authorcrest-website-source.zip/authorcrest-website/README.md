# AuthorCrest website

A responsive, editorial book-marketing agency website using the supplied original logo, teal/ivory/gold design tokens, and the official AuthorCrest email and social links. Built independently of any CRM or dashboard.

## Run locally

Use Node.js 24 and pnpm (lockfile included).

```sh
pnpm install
pnpm dev
pnpm lint
pnpm build
pnpm test
pnpm preview
```

`npm run build` also works after dependencies are installed. The build type-checks, bundles the client, builds a server rendering entry, and writes static HTML for 16 routes plus a branded 404. Output: `dist/`. No Node server is required in production. The local Vite server does not execute Cloudflare Functions; use Wrangler Pages locally for backend testing after configuring bindings.

## What is included

- Homepage with a lazily imported Three.js book, pointer rotation, static/reduced-motion fallback, scroll reveals, service previews, interactive six-stage journey, resource previews, and honest trailer placeholder.
- About, eight detailed service sections, Approach, demonstration Case Studies, searchable/category-filtered Resources, six original articles, Contact, three-step Assessment, Privacy, Terms, and 404.
- Consent-based forms with validation and clear delivery failure states. No inquiries are automatically added to a newsletter.
- Cloudflare Pages Function, server validation, same-origin checks, honeypot, minimum completion time, atomic D1 rate counters, deduplication, authenticated forwarding, and generic errors without secret exposure.
- Pre-rendered content, unique metadata, canonical links, sitemap, Organization structured data, default noindex, hostname-based preview protection, security headers, icons, web manifest, and print-friendly resources.
- Configurable approved-asset registry and reusable caption-capable video component. No client testimonials or results are fabricated.

## Content and design

- `src/content.ts`: service and article copy; process stages.
- `src/main.tsx`: page layouts and shared navigation/footer.
- `src/Forms.tsx`: inquiry and newsletter interfaces.
- `src/Book.tsx`: fictional book artwork and progressive WebGL enhancement.
- `src/styles.css`: palette, typography, responsive layouts, focus states, and print rules.
- `src/content/approved-assets.ts`: unpublished future content registry.
- `public/images/logo.png`: untouched supplied original. Icons are padded proportionally from that source; larger icons cannot recover detail absent from the small original.

The book is fictional. The case study is explicitly a demonstration. The trailer is a labeled placeholder. Policy pages are review templates and are not approved legal documents.

Fonts currently load from Google Fonts (Libre Caslon Display and DM Sans) with local fallback fonts. Self-host licensed font files before launch if the owner wants to eliminate those external requests; reflect the final choice in the privacy notice. No analytics or marketing pixels are installed. Consider privacy-conscious aggregate analytics only after approval and a privacy review; avoid user-level tracking by default.

## Deployment and integration

See [DEPLOYMENT.md](DEPLOYMENT.md) for Cloudflare setup and the delivery-service contract. See [QA.md](QA.md) for evidence, limitations, and the launch checklist. No external account, repository, deployment, or DNS record has been modified.

## Concierge and presentation update

The latest build adds a sourced Trustpilot review and dated score, three fictional book-cover concepts, a playable 18-second motion teaser, a consultation request flow, Spanish/French landing pages and consultation forms, a language selector, richer motion, and a pause-animation control. There are now 22 pre-rendered routes, including the private operator login page.

An AI concierge and human takeover inbox are implemented with server-owned conversation history, session isolation, operator authentication, notification failure handling, and protection against late AI replies after takeover. Notifications target `authorscrestworld@gmail.com`. These features require configuration before they work live. See [CHAT-SETUP.md](CHAT-SETUP.md) for the complete setup and limitations.

