# AI concierge and human takeover

The website contains a real API integration and operator workflow. It does not simulate intelligence for visitors or claim that a human is online. The local Vite preview shows the disconnected state until runtime infrastructure is configured.

## Required setup

1. Apply both SQL migrations to the dedicated website D1 database; retain the binding name `INQUIRY_DB`.
2. Set `OPENAI_API_KEY` as an encrypted Cloudflare secret and `OPENAI_CHAT_MODEL` to an available Responses API model in the funded account. A capable reasoning model can be selected; quality, cost, latency, and availability must be evaluated before launch. No provider credentials were supplied or used during this build.
3. Set a long random `RATE_SALT` and a separate random `OPERATOR_TOKEN` of at least 32 characters. Never put either token in the repository, chat, frontend environment, or notification URL.
4. Configure `DELIVERY_URL` and `DELIVERY_TOKEN` to an approved service supporting the existing inquiry contract **and** `kind: chat_handoff`. The notification recipient is **authorscrestworld@gmail.com**; public website inquiries continue to use **info@authorcrest.world**. `HANDOFF_EMAIL` can override the notification address server-side.
5. Deploy `workers/chat-retention.js` as a **new, separate** Worker bound to the same D1 database. Add the hourly schedule `0 * * * *`. Never replace another Worker. Sessions expire after seven days, and the scheduled cleanup removes expired messages on the next run. Check deletion behavior before accepting public chats.
6. Complete the privacy review, choose provider retention terms, set spending limits in the API account, and test live delivery with approved test data before launching.

## Visitor experience

- The visitor reads a privacy notice and explicitly starts a conversation. A random HttpOnly, Secure, SameSite=Strict cookie authorizes only that conversation.
- The AI receives server-owned conversation history and the actual website’s service/resource knowledge. It can discuss book genre, positioning, launch timing, channel priorities, and next steps in the visitor’s language.
- It cannot invent pricing, book appointments, fabricate reviews/results, claim a human is online, or send notifications by itself. A visible **Talk to a person** action creates the handoff.
- The handoff collects name, follow-up email, and explicit consent. It saves the request in the operator inbox and sends an authenticated email-delivery request to the configured service. The alert contains a fixed operator URL, not login credentials or a session token.
- Notification failure is reported honestly while keeping the request in the inbox. The visitor can retry the request after one minute; the delivery service must honor the handoff idempotency key.
- Updates are fetched every three seconds while the chat is open and the document is visible. This is near-real-time text chat, not a voice call or WebSocket service.

## Your inbox

Open `/operator` on the deployed website and enter the private operator key. The key is held only in the tab’s memory, not localStorage, cookies, or the URL. Data is returned only after server authentication. The page is excluded from the sitemap and always marked noindex; noindex is not its access control.

Select a conversation, read its history, and press **Take over**. The visitor sees that an AuthorCrest team member has joined. AI generation pauses immediately; an AI reply already in progress is discarded atomically if takeover occurs before its save. Send replies as the AuthorCrest team, then close the conversation. Locking or reloading the inbox clears the key from the UI. For additional production protection, place the operator page/API behind your organization’s identity system or Cloudflare Access; do not bypass the API key check.

## Limits and tests

Messages and bodies have size limits; session and IP controls restrict repeated requests. AI generation defaults to 150 attempts per UTC day for the whole site (`CHAT_DAILY_LIMIT`), 2,400 maximum output tokens per reply, and a 60-second provider timeout. This is a coarse capacity limit, not a precise monetary budget. Configure an account budget too.

Tests use in-memory SQLite and simulated OpenAI/email services. They verify session isolation, consent, operator authorization, duplicate handling, notification destination/failure, missing configuration, and takeover during generation. Live provider performance and actual Gmail delivery have not been tested.

The AI implementation follows the [Responses API conversation guidance](https://developers.openai.com/api/docs/guides/conversation-state) and [Responses output format](https://developers.openai.com/api/docs/guides/migrate-to-responses), with `store: false`. This setting does not by itself establish zero retention across providers; review the configured account terms.

## Reviews, languages, and showcase content

The Trustpilot block uses one short public excerpt from Isabella Biscoe’s review, a direct source link, and a dated TrustScore snapshot of 3.7/5 from one review, checked October 29, 2026. It does not label the review as a verified purchase. Update or remove the snapshot when it becomes stale. The carousel supports more approved reviews; it does not repeat the single review to imply multiple customers.

English, Spanish, and French landing pages and consultation forms are available. Existing long-form resources and policy templates remain English and are labeled accordingly on the translated pages. The AI can respond in the visitor’s language when connected.

The three cover designs and 18-second motion teaser are original fictional concepts, clearly labeled as such. The teaser has play, pause, seek, replay, text captions, and reduced-motion support. It is an interactive motion concept, not an exported client video. Approved book/video assets can replace it through the existing asset registry and video component.
